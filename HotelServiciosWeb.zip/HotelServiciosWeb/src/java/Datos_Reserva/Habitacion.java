package Datos_Reserva;

public class Habitacion
{
  private int roomNumber;
  private String roomType;
  private String roomSize;

  public Habitacion(int roomNumber, String roomType, String roomSize)
  {
    this.roomNumber = roomNumber;
    this.roomType = roomType;
    this.roomSize = roomSize;
  }

  public Habitacion()
  {
  }

  public int Obtiene_Numero_Habitacion() {
    return this.roomNumber;
  }

  public void Establece_numero_Habitacion(int roomNumber) {
    this.roomNumber = roomNumber;
  }

  public String Obtiene_Tipo_Habitacion() {
    return this.roomType;
  }

  public void Establece_Tipo_Habitacion(String roomType) {
    this.roomType = roomType;
  }

  public String Obtiene_Tamaño_Habitacion() {
    return this.roomSize;
  }

  public void Establece_Tamaño_Habitacion(String roomSize) {
    this.roomSize = roomSize;
  }
}
