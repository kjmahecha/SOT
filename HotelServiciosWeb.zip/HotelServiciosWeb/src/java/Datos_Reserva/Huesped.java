package Datos_Reserva;

public class Huesped
{
  private String name;
  private String address;
  private int age;

  public Huesped(String name, String address, int age)
  {
    this.name = name;
    this.address = address;
    this.age = age;
  }

  public Huesped()
  {
  }

  public String Obtiene_Nombre() {
    return this.name;
  }

  public void Establece_Nombre(String name) {
    this.name = name;
  }

  public String Obtiene_Direccion() {
    return this.address;
  }

  public void Establece_Direccion(String address) {
    this.address = address;
  }

  public int Obtiene_Edad() {
    return this.age;
  }

  public void Establece_Edad(int age) {
    this.age = age;
  }
}