package Datos_Reserva;

import java.util.Date;

public class Reserva {
    private int reservationID;
    private String guestName;
    private Date reserved_from;
    private Date reserved_to;
    private int roomNumber;

    public int Obtiene_Numero_Habitacion() {
        return roomNumber;
    }

    public void Establece_Numero_Habitacion(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public Date Obtiene_Reserva_Desde() {
        return this.reserved_from;
    }

    public void Establece_Reserva_Desde(Date reserved_from) {
        this.reserved_from = reserved_from;
    }

    public Date Obtiene_Reserva_Hasta() {
        return this.reserved_to;
    }

    public void Establece_Reserva_Hasta(Date reserved_to) {
        this.reserved_to = reserved_to;
    }

    public int Obtiene_Id_Reserva() {
        return this.reservationID;
    }

    public void Establece_Id_reserva(int reservationID) {
        this.reservationID = reservationID;
    }

    public String Obtiene_Nombre_Invitado() {
        return this.guestName;
    }

    public void Establece_Nombre_Invitado(String guestName) {
        this.guestName = guestName;
    }

}