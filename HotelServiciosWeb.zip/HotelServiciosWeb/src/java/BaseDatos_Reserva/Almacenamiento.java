package BaseDatos_Reserva;


import Datos_Reserva.Huesped;
import Datos_Reserva.Reserva;
import Datos_Reserva.Habitacion;
import Excepcion_Reserva.Excepcion_inivitado;
import Excepcion_Reserva.Excepcion_Reserva;
import Excepcion_Reserva.Excepcion_Habitacion;
import Excepcion_Reserva.Excepcion_Almacenamiento;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Almacenamiento {

    Connection connection = null;
    Statement statement = null;
    ResultSet rs = null;
    Properties properties = new Properties();

     public boolean Agrega_Invitado(Huesped guest) throws Excepcion_Almacenamiento, Excepcion_inivitado {

        if (Obtiene_Detalle_Invitado(guest.Obtiene_Nombre()) == null) {

            try {
                connection = Obtiene_Conexion();
                statement = connection.createStatement();

                String sqlStatement = "INSERT INTO GUEST_T VALUES ('" + guest.Obtiene_Nombre()
                                      + "','" + guest.Obtiene_Direccion() + "', " + guest.Obtiene_Edad() + ")";
                statement.execute(sqlStatement);
                return true;
            } catch (SQLException e) {
                throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
            } finally {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {

            throw new Excepcion_inivitado("El invitado ya existe");
        }
    }

    public boolean Agrega_Habitacion(Habitacion room) throws Excepcion_Almacenamiento, Excepcion_Habitacion {

        if (Obtiene_Detalle_Habitacion(room.Obtiene_Numero_Habitacion()) == null) {
            try {
                connection = Obtiene_Conexion();
                statement = connection.createStatement();
                //Execute INSERT SQL Query to add a new row to ROOM_T table
                String sqlStatement = "insert into ROOM_T values ('" + room.Obtiene_Numero_Habitacion()
                                      + "','" + room.Obtiene_Tipo_Habitacion() + "', '" + room.Obtiene_Tamaño_Habitacion() + "')";
                statement.execute(sqlStatement);
                return true;
            } catch (SQLException e) {
                throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
            } finally {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            throw new Excepcion_Habitacion("Habitacion ya Existe");
        }
    }

      public boolean Agrega_Reserva(Reserva reservation)
            throws Excepcion_Almacenamiento, Excepcion_Reserva {
        if (Procesa_Reserva(reservation.Obtiene_Nombre_Invitado(), reservation.Obtiene_Numero_Habitacion())) {
            try {
                connection = Obtiene_Conexion();
                statement = connection.createStatement();
                String sqlStatement = "insert into RESERVATION_T(guest_name,room_no,reserved_from,reserved_to) values ('" + reservation.Obtiene_Nombre_Invitado()
                                      + "','" + reservation.Obtiene_Numero_Habitacion() + "', '" + new java.sql.Date(reservation.Obtiene_Reserva_Desde().getTime()) + "', '" + new java.sql.Date(reservation.Obtiene_Reserva_Hasta().getTime()) + "')";


                statement.execute(sqlStatement);
                return true;
            } catch (SQLException e) {
                throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
            } finally {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            throw new Excepcion_Reserva("Reserva ya Existe");
        }
    }

    public boolean Procesa_Reserva(String guest_name, int roomNumber) throws Excepcion_Almacenamiento {
        ResultSet rs1 = null;
        ResultSet rs2 = null;
        ResultSet rs3 = null;
        ResultSet rs4 = null;
        Statement statement1 = null;
        Statement statement2 = null;
        Statement statement3 = null;
        Statement statement4 = null;

        connection = Obtiene_Conexion();
        try {
            statement1 = connection.createStatement();
            statement2 = connection.createStatement();
            statement3 = connection.createStatement();
            statement4 = connection.createStatement();
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        }
        String sqlStatement1 = "SELECT guest_name, room_no FROM RESERVATION_T where guest_name='" + guest_name + "'";
        String sqlStatement2 = "SELECT guest_name, room_no FROM RESERVATION_T where room_no='" + roomNumber + "'";
        String sqlStatement3 = "SELECT name FROM GUEST_T where name='" + guest_name + "'";
        String sqlStatement4 = "SELECT room_number FROM ROOM_T where room_number='" + roomNumber + "'";
        boolean Procesa_Reserva;
        try {
            rs1 = statement1.executeQuery(sqlStatement1);
            rs2 = statement2.executeQuery(sqlStatement2);
            rs3 = statement3.executeQuery(sqlStatement3);
            rs4 = statement4.executeQuery(sqlStatement4);
            if (rs3.next() == true && rs4.next() == true && rs1.next() == false && rs2.next() == false) {
                Procesa_Reserva = true;
                
            } else {
                Procesa_Reserva = false;
            }

        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        } finally {
            try {
                statement1.close();
                connection.close();
            } catch (Exception e) {
                throw new Excepcion_Almacenamiento("Error Cerrando la Conexion");
            }
        }

        return Procesa_Reserva;
    }

     public Habitacion Obtiene_Detalle_Habitacion(int roomNumber) throws Excepcion_Almacenamiento {


        int roomNo = 0;
        String roomType = null;
        String roomSize = null;

        connection = Obtiene_Conexion();
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("Can not execute the sql query", e);
        }
        String sqlStatement = "SELECT * FROM ROOM_T where room_number = '" + roomNumber + "'";
        try {
            rs = statement.executeQuery(sqlStatement);

            Habitacion room = null;
            while (rs.next()) {
                room = new Habitacion();

                roomNo = rs.getInt("Numero_Habitacion");
                roomType = rs.getString("Tipo_Habitacion");
                roomSize = rs.getString("Tamaño_Habitacion");

                room.Establece_numero_Habitacion(roomNo);
                room.Establece_Tipo_Habitacion(roomType);
                room.Establece_Tamaño_Habitacion(roomSize);

            }
            return room;
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        } finally {
            try {
                statement.close();
                connection.close();
            } catch (Exception e) {
                throw new Excepcion_Almacenamiento("Error Cerrando la Conexion");
            }
        }


    }

    public Reserva Obtiene_Detalle_Reserva(int roomNumber) throws Excepcion_Almacenamiento {

        int resID = 0;
        String guestName = null;
        Date reservedFrom = null;
        Date reservedTo = null;


        connection = Obtiene_Conexion();
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        }

        String sqlStatement = "SELECT * FROM RESERVATION_T where room_no = '" + roomNumber + "'";
        try {
            rs = statement.executeQuery(sqlStatement);

            Reserva reservation = null;
            while (rs.next()) {
                reservation = new Reserva();

                resID = rs.getInt("Id_Reserva");
                guestName = rs.getString("Nombre_Invitado");
                roomNumber = rs.getInt("No_Habitacion");
                reservedFrom = rs.getDate("Reserva_desde");
                reservedTo = rs.getDate("Reserva_Hasta");

                reservation.Establece_Id_reserva(resID);
                reservation.Establece_Nombre_Invitado(guestName);
                reservation.Establece_Numero_Habitacion(roomNumber);
                reservation.Establece_Reserva_Desde(reservedFrom);
                reservation.Establece_Reserva_Hasta(reservedTo);


            }
            return reservation;
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        } finally {
            try {
                statement.close();
                connection.close();
            } catch (Exception e) {
                throw new Excepcion_Almacenamiento("Error Cerrando la Conexion");
            }
        }


    }

     public Huesped Obtiene_Detalle_Invitado(String name) throws Excepcion_Almacenamiento {

        String guestName = null;
        String guestAddress = null;
        int guestAge = 0;


        connection = Obtiene_Conexion();
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        }

        String sqlStatement = "SELECT * FROM GUEST_T WHERE name = '" + name + "'";
        try {
            rs = statement.executeQuery(sqlStatement);

            Huesped guest = null;
            while (rs.next()) {
                guest = new Huesped();

                guestName = rs.getString("Nombre");
                guestAddress = rs.getString("Direccion");
                guestAge = rs.getInt("Edad");

                guest.Establece_Nombre(guestName);
                guest.Establece_Edad(guestAge);
                guest.Establece_Direccion(guestAddress);

            }
            return guest;
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        } finally {
            try {
                statement.close();
                connection.close();
            } catch (Exception e) {
                throw new Excepcion_Almacenamiento("Error Cerrando la Conexion");
            }
        }

    }

    public void Elimina_Invitado(String name) throws Excepcion_Almacenamiento, Excepcion_inivitado {

        if (Obtiene_Detalle_Invitado(name) != null) {

            try {
                connection = Obtiene_Conexion();
                statement = connection.createStatement();

                String sqlStatement = "DELETE FROM GUEST_T WHERE name = '" + name + "'";
                statement.execute(sqlStatement);
            } catch (SQLException e) {
                throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
            } finally {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {

            throw new Excepcion_inivitado("Invitado no Existe");

        }

    }
    public void deleteRoom(int roomNumber) throws Excepcion_Almacenamiento, Excepcion_Habitacion {

        if (Obtiene_Detalle_Habitacion(roomNumber) != null) {

            try {
                connection = Obtiene_Conexion();
                statement = connection.createStatement();
                String sqlStatement = "delete from ROOM_T where room_number = '" + roomNumber + "'";
                statement.execute(sqlStatement);
            } catch (SQLException e) {
                throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
            } finally {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {

            throw new Excepcion_Habitacion("Habitacion no Existe");

        }

    }

     private Connection Obtiene_Conexion() throws Excepcion_Almacenamiento {
        String driverName = "com.mysql.jdbc.Driver";
        String host = null;
        String port = null;
        String userName = null;
        String password = null;
        String conectionURI = null;

        try {
             InputStream propertyInputStream = this.getClass().getClassLoader().getResourceAsStream("conf/mysql.properties");
            properties.load(propertyInputStream);
            userName = properties.getProperty("mysql.username");
            password = properties.getProperty("mysql.password");
            host = properties.getProperty("mysql.host");
            port = properties.getProperty("mysql.port");

            conectionURI = "jdbc:mysql://" + host + ":" + port + "/HOTEL_RESERVATION_DB";
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            Class driverClass = Class.forName(driverName);
            Connection connection = DriverManager.getConnection(conectionURI, userName, password);
            connection.setAutoCommit(true);
            return connection;
        } catch (ClassNotFoundException e) {
            throw new Excepcion_Almacenamiento("No se pudo encontrar clase Control ", e);
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo conectar a Base de Datos", e);
        }
    }
    public void removeReservation(int reservationID)
            throws Excepcion_Almacenamiento, Excepcion_Reserva {
        try {
            connection = Obtiene_Conexion();
            statement = connection.createStatement();

            String sqlStatement = "DELETE FROM RESERVATION_T WHERE res_id = " + reservationID + "";
            statement.execute(sqlStatement);
        } catch (SQLException e) {
            throw new Excepcion_Almacenamiento("No se pudo ejecutar el Query", e);
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
