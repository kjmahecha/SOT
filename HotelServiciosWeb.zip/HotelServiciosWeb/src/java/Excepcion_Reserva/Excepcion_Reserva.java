package Excepcion_Reserva;

public class Excepcion_Reserva extends Exception {
    private String message;

    public Excepcion_Reserva() {
    }

    public Excepcion_Reserva(String message) {
        super(message);
    }

    public Excepcion_Reserva(String message, Throwable cause) {
        super(message, cause);
    }

    public Excepcion_Reserva(Throwable cause) {
        super(cause);
    }

    public String getMessage() {
        return super.getMessage();
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
