package Excepcion_Reserva;

public class Excepcion_Almacenamiento extends Exception {
    public Excepcion_Almacenamiento() {
    }

    public Excepcion_Almacenamiento(String message) {
        super(message);
    }

    public Excepcion_Almacenamiento(String message, Throwable cause) {
        super(message, cause);
    }

    public Excepcion_Almacenamiento(Throwable cause) {
        super(cause);
    }
}
