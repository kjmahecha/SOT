package Excepcion_Reserva;

public class Excepcion_inivitado extends Exception {
    private String message;

    public Excepcion_inivitado() {
    }

    public Excepcion_inivitado(String message) {
        super(message);
    }

    public Excepcion_inivitado(String message, Throwable cause) {
        super(message, cause);
    }

    public Excepcion_inivitado(Throwable cause) {
        super(cause);
    }

    public String getMessage() {
        return super.getMessage();
    }

    public void Envia_Mensaje(String message) {
        this.message = message;
    }
}
