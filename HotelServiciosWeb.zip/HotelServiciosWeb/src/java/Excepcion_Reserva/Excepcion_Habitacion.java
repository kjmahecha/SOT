package Excepcion_Reserva;

public class Excepcion_Habitacion extends Exception {
    private String message;

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return super.getMessage();
    }

    public Excepcion_Habitacion() {
    }

    public Excepcion_Habitacion(String message) {
        super(message);
    }

    public Excepcion_Habitacion(String message, Throwable cause) {
        super(message, cause);
    }

    public Excepcion_Habitacion(Throwable cause) {
        super(cause);
    }
}
