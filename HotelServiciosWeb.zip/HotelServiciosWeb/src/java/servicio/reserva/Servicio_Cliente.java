package servicio.reserva;

import BaseDatos_Reserva.Almacenamiento;
import Datos_Reserva.Huesped;
import Excepcion_Reserva.Excepcion_inivitado;
import Excepcion_Reserva.Excepcion_Almacenamiento;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "Servicio_Cliente")
public class Servicio_Cliente {

   

    @WebMethod(operationName = "Agrega_Invitado")
    public boolean Agrega_Invitado(@WebParam(name = "Nombre") String name, @WebParam(name = "Direccion") String address, @WebParam(name = "Edad") int age)
            throws Excepcion_inivitado {
        Huesped Invitado = new Huesped();
        Invitado.Establece_Nombre(name);
        Invitado.Establece_Direccion(address);
        Invitado.Establece_Edad(age);

        Almacenamiento storage = new Almacenamiento();
        Excepcion_inivitado Excepcion;
        try {
            storage.Agrega_Invitado(Invitado);
            return true;
        } catch (Excepcion_Almacenamiento e) {
            Excepcion = new Excepcion_inivitado();
            Excepcion.Envia_Mensaje(e.getMessage());
            e.printStackTrace();
        }
        throw Excepcion;
    }
   
    @WebMethod(operationName = "Obtiene_Detalle_Invitado")
    public Huesped Obtiene_Detalle_Invitado(@WebParam(name = "Nombre_Invitado") String guestName) throws Excepcion_inivitado {
        Almacenamiento storage = new Almacenamiento();
        Excepcion_inivitado exception;
        try {
            Huesped guest = storage.Obtiene_Detalle_Invitado(guestName);
            if (guest != null) {
                return guest;
            }

            throw new Excepcion_inivitado("Invitado no Existe! ");
        } catch (Excepcion_Almacenamiento e) {
            exception = new Excepcion_inivitado();
            exception.Envia_Mensaje(e.getMessage());
            e.printStackTrace();
        }
        throw exception;
    }

    
    @WebMethod(operationName = "Elimina_Invitado")
    public void Elimina_Invitado(@WebParam(name = "Nombre_Invitado") String guestName)
            throws Excepcion_inivitado {
        Almacenamiento storage = new Almacenamiento();
        try {
            Huesped guest = storage.Obtiene_Detalle_Invitado(guestName);
            storage.Elimina_Invitado(guest.Obtiene_Nombre());
        } catch (Excepcion_Almacenamiento e) {
            Excepcion_inivitado exception = new Excepcion_inivitado();
            exception.Envia_Mensaje(e.getMessage());
            e.printStackTrace();
            throw exception;
        }
    }

}
